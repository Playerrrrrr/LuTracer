#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main() {
	char buf[16];

	memset(buf, 0, 16);		
	printf("please input a word!\n");
	
	printf("%7$#x\n");
	
	scanf("%s", buf);

	return 0;

}

