#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

void over_write() {
	unsigned int val;
	unsigned int addr;
	printf("please input an addr\n");
	scanf("%x", &addr);
	printf("please input a value\n");
	scanf("%x", &val);
	memcpy((void*)addr, &val, sizeof(int));
	printf("%x replaced %x\n", addr, val);
	printf("%x, %x\n", addr,  *(unsigned int*)addr);
}

void wh(const char* w) {
	if(strncmp(w, "say", 3) == 0) {
		printf("you said hello world!\n");
	} else {
		printf("you said fuck you!\n");
	}
	over_write();
}

int main() {
	char buf[16];
	memset(buf, 0, 16);		
	printf("please input a word!\n");
	scanf("%s", buf);
	wh(buf);
	return 0;
}


