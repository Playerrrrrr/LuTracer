#include <stdlib.h>
#include <stdio.h>
#include <string.h>



void wh(const char* w) {
	if(strncmp(w, "say", 3) == 0) {
		printf("you said hello world!\n");
	} else {
		printf("you said fuck you!\n");
	}
}


int main() {
	char buf[16];

	memset(buf, 0, 16);		
	printf("please input a word!\n");
	
	scanf("%s", buf);

	wh(buf);
	return 0;

}


