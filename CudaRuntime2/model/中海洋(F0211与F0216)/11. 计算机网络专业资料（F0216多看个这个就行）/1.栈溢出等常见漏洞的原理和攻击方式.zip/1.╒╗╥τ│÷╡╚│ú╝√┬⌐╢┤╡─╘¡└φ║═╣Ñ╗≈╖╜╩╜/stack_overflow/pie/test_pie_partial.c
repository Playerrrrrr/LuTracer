#include <stdlib.h>
#include <stdio.h>
#include <string.h>

void evil() {
	system("ls -al");
}

void wh() {
	char buf[16];
	memset(buf, 0, 16);		
			
	printf("please input a word!\n");
	scanf("%s", buf);
	printf(buf);
}

int main() {
	wh();

	return 0;
}


