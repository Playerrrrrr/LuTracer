#!/bash/shell
for ((i=1; i<=8; i++))
do
	python test_pie_partial.py
done
