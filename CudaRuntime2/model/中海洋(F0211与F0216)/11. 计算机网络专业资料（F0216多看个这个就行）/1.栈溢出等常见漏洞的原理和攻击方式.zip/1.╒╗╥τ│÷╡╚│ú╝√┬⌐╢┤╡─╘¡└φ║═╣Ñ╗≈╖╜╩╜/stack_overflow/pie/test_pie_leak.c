#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
int is_leak = 0;
void show_msg() {
	char buf[16];
	memset(buf, 0, 16);
	printf("please input the message!\n");
	scanf("%s", buf);
	printf("you message : %s\n", buf);
	if(!is_leak) {
		printf("%11$.8x\n");
		is_leak = 1;
	}
	/*printf("%.8x\n", buf);
	printf("please input an address!\n");
	int addr;
	scanf("%x", &addr);
	printf("input addr %x\n", addr);
	size_t n = write(1, (void*)addr, 4);
	if(n == -1) {
		perror("write");
	}*/
}

int main() {
	while(1) {
		printf("Enter your choice:\n	1: show data\n	2: exit program\n");
		int choice = 0;
		scanf("%d", &choice);

		switch(choice) {
			case 1:
				show_msg();
				break;
			default:
				exit(0);
		}
	}
	return 0;
}


