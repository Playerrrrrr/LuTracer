#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

int main(int argc, char** argv) {

	int a;
	scanf("%x", a);
	printf("%x\n", a);
	return 0;
}


