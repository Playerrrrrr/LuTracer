#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

void evil() {
	system("ls -al");
}

int main(int argc, char** argv) {
	
	int* a = (int*) malloc(sizeof(int));
	int b = 11;
	a = &b;
	puts("call puts\n");
	printf("%120d%n\n", b, a);
	printf("a = %d\n", *a);
	printf("puts %p, system %p\n", puts, system);
	int* puts_got = (int*)0x80497dc;
	printf("%134513488d%n\n", b, puts_got);
	puts("ls -al");
	// free(a); // it can't be freed!
	// a = NULL;	
	return 0;
}


