#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

int main(int argc, char** argv) {
	
	printf("%#x-%#x-%#x-%#x-%#x-%#x-%#x\n");
	printf("%1$#x-%2$#x-%3$#x-%4$#x-%5$#x-%6$#x-%7$#x\n");
	return 0;
}


