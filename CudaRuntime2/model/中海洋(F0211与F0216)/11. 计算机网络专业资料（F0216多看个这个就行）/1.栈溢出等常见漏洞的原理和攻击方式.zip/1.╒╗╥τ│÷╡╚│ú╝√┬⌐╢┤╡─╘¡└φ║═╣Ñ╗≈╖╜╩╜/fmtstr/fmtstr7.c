#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

int main(int argc, char** argv) {
	
	int a = 10;
	char* b = "hello";	
	printf("%#x-%#x-%#x-%#x-%#x-%#x-%#x\n");
	printf("%#x-%#x-%#x-%#x-%#x-%#x-%#x\n", a, b);
	printf("%1$#x-%2$#x-%#x-%#x-%#x-%#x-%#x\n", a, b);
	printf("%1$#x-%2$s-%3$#x-%4$#x-%5$#x-%6$#x-%7$#x\n");
	return 0;
}


