#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

int main(int argc, char** argv) {
	
	int a = 10;
	printf("a = %d\n", a);
	printf("%p\n", &a);
	char test[100];
	scanf("%s", test);
	printf(test);	
	printf("a = %d\n", a);
	return 0;
}


