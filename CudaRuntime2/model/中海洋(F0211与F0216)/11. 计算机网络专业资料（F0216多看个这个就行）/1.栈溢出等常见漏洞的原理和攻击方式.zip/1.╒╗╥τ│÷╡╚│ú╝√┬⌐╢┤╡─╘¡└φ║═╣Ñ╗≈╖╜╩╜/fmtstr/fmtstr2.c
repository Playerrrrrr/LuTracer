#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

int main(int argc, char** argv) {
	int a = 10;	
	printf("%d\n%.8x\n", a);
	return 0;
}


