#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

int main(int argc, char** argv) {
	
	int a = 11;
	int b = 12;
	int c = 13;
	printf("a = %d, b =  %d, c = %d\n", a, b, c);
	printf("%100d%n%100d%n%100d%n\n", 1, &a, 2, &b, 3, &c);
	printf("a = %d, b =  %d, c = %d\n", a, b, c);
	return 0;
}


