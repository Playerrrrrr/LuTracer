#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

int main(int argc, char** argv) {
	
	int a = 10;
	char* b = "hello";	
	printf("%#x-%#x-%s-%#x-%#x-%#x-%#x\n", a, b);
	return 0;
}


