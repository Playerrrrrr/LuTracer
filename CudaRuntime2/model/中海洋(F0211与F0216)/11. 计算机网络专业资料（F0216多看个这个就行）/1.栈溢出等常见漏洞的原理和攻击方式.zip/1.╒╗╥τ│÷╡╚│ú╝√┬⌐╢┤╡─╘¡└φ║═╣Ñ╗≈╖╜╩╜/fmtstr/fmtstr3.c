#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

int main(int argc, char** argv) {
	
	int a = 10;
	char* s = "hello";
	char c = 'A';
	int d = 0;
	printf("%d-%s-%x-%c-%p-%d\n", a, s, s, c, &d, d);
	printf("%d%n\n", 120, &d);
	printf("%d\n", d);
	printf("%2$#x\n", a, s);
	return 0;
}


