#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

void evil() {
	system("ls -al");
}

int main(int argc, char** argv) {
	char test[100];
	scanf("%s", test);
	printf(test);	
	return 0;
}


