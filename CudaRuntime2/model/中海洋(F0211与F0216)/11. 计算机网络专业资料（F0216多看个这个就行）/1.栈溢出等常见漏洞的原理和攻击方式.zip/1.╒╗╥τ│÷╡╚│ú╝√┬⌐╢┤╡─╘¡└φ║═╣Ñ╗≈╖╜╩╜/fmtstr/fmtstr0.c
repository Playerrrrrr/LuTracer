#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

int main(int argc, char** argv) {
	if (argc < 3) {
		printf("Input fmtstr!\n");
		exit(-1);		
	}

	char* fmt = argv[1];
	char* args = argv[2];
	
	printf(fmt);
	printf(fmt, args);
	printf("\n");
	return 0;
}


