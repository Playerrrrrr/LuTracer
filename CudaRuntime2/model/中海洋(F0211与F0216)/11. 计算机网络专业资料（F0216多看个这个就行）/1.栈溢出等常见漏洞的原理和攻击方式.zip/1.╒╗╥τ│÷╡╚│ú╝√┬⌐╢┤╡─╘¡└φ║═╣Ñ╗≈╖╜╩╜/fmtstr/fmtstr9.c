#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

void evil() {
	system("ls -al");
}

int main(int argc, char** argv) {
	char* s = "AAAA";
	printf("%#x-%#x-%#x-%#x-%#x-%#x-%s-%#x\n");	
	return 0;
}


