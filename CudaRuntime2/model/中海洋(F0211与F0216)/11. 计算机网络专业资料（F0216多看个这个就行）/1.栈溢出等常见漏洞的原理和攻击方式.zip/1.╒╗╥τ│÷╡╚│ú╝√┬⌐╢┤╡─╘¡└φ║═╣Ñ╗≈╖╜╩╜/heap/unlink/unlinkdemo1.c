#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

void evil() {
	printf("you are hacked!\n");
}

int main(int argc, char** argv) {

	void* ptr1, *ptr2, *ptr3;
	ptr1 = malloc(0x80); //  > fastbin 
	ptr2 = malloc(0x10); // consolidate forward 
	ptr3 = malloc(0x10); // nnextchun 
 
	if(argc != 1) {
		printf("into\n");
		strcpy((char*)ptr1, argv[1]); // heap overflow
	}
	free(ptr1);

	free(ptr2);// exec evil	
	return 0;	
}
