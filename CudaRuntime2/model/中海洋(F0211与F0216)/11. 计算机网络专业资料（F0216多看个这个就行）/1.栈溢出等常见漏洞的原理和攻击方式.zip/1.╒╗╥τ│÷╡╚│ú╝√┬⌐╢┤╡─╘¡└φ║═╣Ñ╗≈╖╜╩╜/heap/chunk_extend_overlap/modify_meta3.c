#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#define NBINS 128
#define BINMAPSHIFT      5
#define BITSPERMAP       (1U << BINMAPSHIFT)
#define BINMAPSIZE       (NBINS / BITSPERMAP)


#define NSMALLBINS         64
#define SMALLBIN_WIDTH    MALLOC_ALIGNMENT
#define SMALLBIN_CORRECTION (MALLOC_ALIGNMENT > 2 * SIZE_SZ)
#define MIN_LARGE_SIZE    ((NSMALLBINS - SMALLBIN_CORRECTION) * SMALLBIN_WIDTH)

#define in_smallbin_range(sz)  \
  ((unsigned long) (sz) < (unsigned long) MIN_LARGE_SIZE)

#ifndef offsetof
# define offsetof(type,ident) ((size_t)&(((type*)0)->ident))
#endif


#ifndef INTERNAL_SIZE_T
# define INTERNAL_SIZE_T size_t
#endif

#define SIZE_SZ (sizeof (INTERNAL_SIZE_T))


/* size field is or'ed with PREV_INUSE when previous adjacent chunk in use */
#define PREV_INUSE 0x1

/* extract inuse bit of previous chunk */
#define prev_inuse(p)       ((p)->mchunk_size & PREV_INUSE)


/* size field is or'ed with IS_MMAPPED if the chunk was obtained with mmap() */
#define IS_MMAPPED 0x2

/* size field is or'ed with NON_MAIN_ARENA if the chunk was obtained
 *    from a non-main arena.  This is only set immediately before handing
 *       the chunk to the user, if necessary.  */
#define NON_MAIN_ARENA 0x4

#define SIZE_BITS (PREV_INUSE | IS_MMAPPED | NON_MAIN_ARENA)

/* Get size, ignoring use bits */
#define chunksize(p) (chunksize_nomask (p) & ~(SIZE_BITS))

/* Like chunksize, but do not mask SIZE_BITS.  */
#define chunksize_nomask(p)         ((p)->mchunk_size)

struct malloc_chunk {

  INTERNAL_SIZE_T      mchunk_prev_size;  /* Size of previous chunk (if free).  */
  INTERNAL_SIZE_T      mchunk_size;       /* Size in bytes, including overhead. */

  struct malloc_chunk* fd;         /* double links -- used only if free. */
  struct malloc_chunk* bk;

  /* Only used for large blocks: pointer to next larger size.  */
  //struct malloc_chunk* fd_nextsize; /* double links -- used only if free. */
  //struct malloc_chunk* bk_nextsize;
};
  
typedef struct malloc_chunk* mchunkptr;

#define PRINT_META(p) printf("p = %p, mem = %p, p->mchunk_prev_size = %x, p->mchunk_size = %x, prev_inuse = %d\n",\
				p, ((char*)p + 2*SIZE_SZ), p->mchunk_prev_size,\
				chunksize(p), prev_inuse(p)) 

int main() {

	void* ptr1, *ptr2, *ptr3, *ptr4;
	ptr1 = malloc(0x220); // largebin
	ptr2 = malloc(0x10); // 
	ptr4 = malloc(0x10); // prevent combining with top chunk
	memset(ptr2, 'A', 0x10);
	printf("*ptr2 = %c\n", *(char*)ptr2);

	mchunkptr p1 = (mchunkptr) (ptr1 - 2*SIZE_SZ);
      	mchunkptr p2 = (mchunkptr) (ptr2 - 2*SIZE_SZ);
	PRINT_META(p1);
	PRINT_META(p2);

        p1->mchunk_size = 0x240 | PREV_INUSE;
        free(ptr1);

	ptr3 = malloc(0x238);
      	mchunkptr p3 = (mchunkptr) (ptr3 - 2*SIZE_SZ);
	PRINT_META(p3);

	memset(ptr3, 'B', 0x238);
	printf("*ptr2 = %c\n", *(char*)ptr2);

	return 0;	
}
