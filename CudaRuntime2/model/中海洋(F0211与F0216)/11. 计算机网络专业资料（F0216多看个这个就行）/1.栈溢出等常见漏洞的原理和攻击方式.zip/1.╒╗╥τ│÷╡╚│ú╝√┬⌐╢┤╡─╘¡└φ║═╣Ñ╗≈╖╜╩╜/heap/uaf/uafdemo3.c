#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main() {

	int* p1 = malloc(sizeof(int));	
	int a = 10;
	p1 = &a;
	printf("*p = %d\n", *p1);

	free(p1);
	
	printf("*p = %d\n", *p1);
	
	return 0;

}
