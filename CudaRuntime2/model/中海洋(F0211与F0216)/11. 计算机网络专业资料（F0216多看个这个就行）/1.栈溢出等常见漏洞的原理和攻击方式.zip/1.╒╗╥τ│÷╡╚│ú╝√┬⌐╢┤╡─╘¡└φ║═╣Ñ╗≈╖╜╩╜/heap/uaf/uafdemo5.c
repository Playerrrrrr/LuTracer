#include <stdlib.h>
#include <stdio.h>
#include <string.h>

struct demo {
	char* name;
	int age;
};

typedef struct demo* DEMO;

int main() {
	
	char* name = "ahacker";
	DEMO d = (DEMO)malloc(sizeof(DEMO));
	d->name = (char*) malloc(strlen(name)+1);
	memset(d->name, 0, (strlen(name) +1));
	strcpy(d->name, name);
	d->age = 20;
	printf("demo :\nname = %s, age = %d\n", d->name, d->age);
	
	free(d);
	name = "ahooker";
	strcpy(d->name, name);
	d->age = 25;
	printf("demo :\nname = %s, age = %d\n", d->name, d->age);

	return 0;

}
