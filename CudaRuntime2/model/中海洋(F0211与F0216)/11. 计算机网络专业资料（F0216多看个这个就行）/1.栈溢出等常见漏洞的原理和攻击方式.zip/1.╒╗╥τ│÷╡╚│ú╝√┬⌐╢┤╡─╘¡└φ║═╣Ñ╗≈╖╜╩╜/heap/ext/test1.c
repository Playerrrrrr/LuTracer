#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main() {

	char* str= "111111112222222233333333444444445555555566666666";

	char* p1 = (char*) malloc(8);
	strcpy(p1, str);

	printf("p1 = %p, p1 = %s\n", p1, p1);
	char* p2 = malloc(8);
	printf("p2 = %p, p2 = %s\n", p2, p2);
	return 0;
}
