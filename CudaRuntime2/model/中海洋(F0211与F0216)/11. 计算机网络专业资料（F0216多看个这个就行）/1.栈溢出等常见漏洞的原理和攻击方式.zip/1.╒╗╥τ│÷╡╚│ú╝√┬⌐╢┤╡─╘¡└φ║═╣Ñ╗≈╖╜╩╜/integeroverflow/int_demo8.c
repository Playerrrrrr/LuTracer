#include<stdlib.h>
#include <stdio.h>
#include <string.h>
#define MAX_BUF_LEN 256
int main(int argc, char** argv) {
	unsigned char buflen = 0;

	int* buf = (int*) malloc(MAX_BUF_LEN * sizeof(int));
	char* second = (char*) malloc(0x10);

	if (argc > 1) {
		buflen = (unsigned char)atoi(argv[1]);
	} else {
		printf("Bad input!\n");
		exit(-1);
	}

	if(buflen > MAX_BUF_LEN) {
		printf("Bad input!\n");
                exit(-1);
	}

	memset(buf, 'A', MAX_BUF_LEN * sizeof(int));	
	memset(second, 'B', 0x10);	
	printf("buf[0] = 0x%.8x\n", buf[0]);
	printf("buf[%d] = 0x%.8x\n", atoi(argv[1]), (buf[atoi(argv[1])]));

	return 0;
}
