#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main() {


	printf("%d, %d, %d, %d, %d\n", sizeof(char), sizeof(short),
		 sizeof(int), sizeof(long), sizeof(long long));

	/*
	char a = 0x10;
	unsigned char b = 0x11;
	short c = 0x100;
	unsigned short d = 0x101;
	int e = 0x1000;
	unsigned int f = 0x1001;
	long g = 0x10000;
	unsigned long h = 0x10001;
	long long i = 0x100000;
	unsigned long long j = 0x100001;
	*/
	char a = 0x10;
	unsigned char a1 = (unsigned char)a;
        unsigned char b = 0x11;
	char b1 = (char) b;	
        short c = 0x100;
	unsigned short c1 = (unsigned short) c;
        unsigned short d = 0x101;
	short d1 = (short) d;
        int e = 0x1000;
	unsigned int e1 = (unsigned int) e;
        unsigned int f = 0x1001; 
	int f1 = (int) f;
        long g = 0x10000;
	unsigned long g1 = (unsigned long) g;
        unsigned long h = 0x10001;
	long h1 = (long) h;
        long long i = 0x100000;
	unsigned long long i1 = (unsigned long long) i;
        unsigned long long j = 0x100001;
	long long j1 = (long long) j;

	unsigned int k  = (unsigned int) a;
	k = (unsigned short)c;
	int l = (int) a;
	l = c;
	a = (char) e;
	a = (char) f;
	c = (short) e;
	c = (short) f;
	i = (long long) e;
	i = (long long) f;		
	printf("====================================================\n");
	
	printf("%c, %c, %d, %u, %d, %u, %d, %u, %ld, %lu, %d, %d\n",
		a1, b1, c1, d1, e1, f1, g1, h1, i1, j1, k, l);
	return 0;
}
