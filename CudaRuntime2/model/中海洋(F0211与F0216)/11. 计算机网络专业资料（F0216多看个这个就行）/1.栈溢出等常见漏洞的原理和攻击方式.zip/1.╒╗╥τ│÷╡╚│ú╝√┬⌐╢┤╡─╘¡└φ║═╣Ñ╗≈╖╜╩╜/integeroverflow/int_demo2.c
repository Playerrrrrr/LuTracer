#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main() {

	int c = -1;
	printf("c = %d\n", c);
	unsigned int i  = 256;
	printf("i = %d\n", i);
	i = c;// 把signed int型转换为unsigned int型
	printf("i = %u\n", c);
	return 0;
}
