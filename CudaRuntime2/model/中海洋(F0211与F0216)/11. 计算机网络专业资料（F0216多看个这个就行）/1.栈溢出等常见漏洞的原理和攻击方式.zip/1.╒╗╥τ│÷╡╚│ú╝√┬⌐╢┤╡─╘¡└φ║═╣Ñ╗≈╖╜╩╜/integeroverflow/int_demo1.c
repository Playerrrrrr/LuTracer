#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main() {

	char c = 12;
	printf("c = %d\n", c);
	int i  = 256;
	printf("i = %d\n", i);
	c = i;// 把signed int型转换为signed char型
	printf("c = %d\n", c);
	return 0;
}
