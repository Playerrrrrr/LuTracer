#include<stdlib.h>
#include <stdio.h>
#include <string.h>
#define MAX_BUF_LEN 256
int main(int argc, char** argv) {
	unsigned char buflen = 0;
	char* arg = NULL;

	char buf[MAX_BUF_LEN];
	if (argc > 1) {
		arg = argv[1];
		buflen = (unsigned char)strlen(arg);
	} else {
		printf("Bad input!\n");
		exit(-1);
	}

	if(buflen > MAX_BUF_LEN || arg == NULL) {
		printf("Bad input!\n");
                exit(-1);
	}

	printf("input buf len = %d\n", buflen);
	memset(buf, 0, MAX_BUF_LEN);	
	strncpy(buf, arg, strlen(arg));
	printf("buf = %s\n", buf);

	return 0;
}
