#include <stdlib.h>
#include <stdio.h>
#include <string.h>


unsigned int sum(int a, int b) {
	unsigned int x = a;
	unsigned int y = b;
	
	return (unsigned int)(x + y);
}

int main() {
	int a = -1, b = -1;
	printf("a + b = %u\n", sum(a, b));
	return 0;
}
