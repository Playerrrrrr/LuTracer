#include<stdlib.h>
#include <stdio.h>
#include <string.h>

#define MAXFLAG 255
void exec() {
	// do logic
	printf("do a lot logic, but dangerous, we don't expect it to execute!\n");
}

int main(int argc, char** argv) {
	int a = 0;
	if (argc > 1) {
		a = (int)atoi(argv[1]);
	} else {
		printf("Bad input!\n");
		exit(-1);
	}

	if(a > 254) {
		printf("Bad input!\n");
                exit(-1);
	}

	printf("input flag = %d\n", a);
	
	if( (char)(MAXFLAG - a) == 0) {
		exec();
	}
	return 0;
}
