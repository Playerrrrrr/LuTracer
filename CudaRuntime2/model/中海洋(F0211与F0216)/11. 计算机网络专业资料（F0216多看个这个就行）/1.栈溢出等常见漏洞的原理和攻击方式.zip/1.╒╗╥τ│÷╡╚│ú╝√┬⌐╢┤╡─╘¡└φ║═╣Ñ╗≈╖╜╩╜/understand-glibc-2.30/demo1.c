#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#define PRINT_BRK printf("break = %p\n", sbrk(0))
int main() {
	void* heap_begin = sbrk(0);
	printf("heap begin = %p\n", heap_begin);
	void* a = malloc(9);
	printf("break = %p, a = %p\n", sbrk(0), a);
	void* b = malloc(40);
	printf("break = %p, b = %p\n", sbrk(0), b);
	void* c = malloc(1);
	printf("break = %p, c = %p\n", sbrk(0), c);
	void* d = malloc(131 * 1024 + 800);	
	printf("break = %p, d = %p\n", sbrk(0), d);
	void* e = malloc(10 * 1024);	
	printf("break = %p, e = %p\n", sbrk(0), e);
	free(e);PRINT_BRK;free(d);PRINT_BRK;
	free(c);PRINT_BRK;free(b);PRINT_BRK;
	free(a);PRINT_BRK;
	printf("=========================\n");
	PRINT_BRK;
	PRINT_BRK;
	PRINT_BRK;
	return 0;
}

