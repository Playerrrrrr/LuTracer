#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

int main() {
	void* heap_begin = sbrk(0);
	printf("heap begin = %p\n", heap_begin);
	void* heap1 = sbrk(16);
	printf("increment 16 bytes, heap = %p\n", heap1);
	void* heap_end = sbrk(0);
	printf("break = %p\n", heap_end);
	void* heap2 = sbrk(-4);
	printf("dec 4 bytes, heap = %p\n", heap2);
	heap_end = sbrk(0);
	printf("break = %p\n", heap_end);
	if (!brk((void*)0x804b000)) {
		heap_end = sbrk(0);
		printf("break = %p\n", heap_end);
	}
	if (!brk((void*)0x804a000)) {
		heap_end = sbrk(0);
		printf("break = %p\n", heap_end);
	}	

	return 0;
}



