#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "R_STDLIB.C"
#include "R_RANDOM.C"
#include "NN.C"
#include "RSA.C"
#include "DIGIT.C"
#include "MD5C.C"
#include "MD2C.C"
#include "PRIME.C"
#include "R_KEYGEN.C"
#include "DESC.C"
#include "R_ENHANC.C"
#include "R_ENCODE.C"
// ��ʮ��������ʽ��ʾoutput�е�����
void shows (char *msg, unsigned char *output, unsigned int len)
{  
   printf ("%s: ", msg);
   for (unsigned int i=0; i<len; i++)
	  printf("%x", output[i]);
   printf("\n");
}
//���������ṹ��
void seed_randomStruct (unsigned char *seed, R_RANDOM_STRUCT *randomStruct)
{
    unsigned int bytesNeeded = 256;  //�ṹ���������ӳ���

    R_RandomInit (randomStruct);	
    while (bytesNeeded > 0)
    { 
       R_RandomUpdate (randomStruct, seed, 
                                       strlen((char *)seed));
	   R_GetRandomBytesNeeded (&bytesNeeded, 
                                                        randomStruct);
	}
}
//����RSA��Կ
void create_RSAkey (R_RSA_PUBLIC_KEY *publicKey, R_RSA_PRIVATE_KEY *privateKey,  unsigned int modul_bits,
     int useFermat4, R_RANDOM_STRUCT *randomStruct)
{
   R_RSA_PROTO_KEY   protoKey;
   int flag;

   protoKey.bits = modul_bits;           //�趨ģ������
   protoKey.useFermat4 = useFermat4;      //�趨e
   flag = R_GeneratePEMKeys 
         (publicKey, privateKey, &protoKey, randomStruct);   // ����RSA��Կ
    if (RE_MODULUS_LEN == flag)
    {  printf ("modulus length invalid\n");  exit(0); }
    else if (RE_NEED_RANDOM == flag)
    {  printf ("randomStruct is not seeded\n");  exit(0); }
}
int main(int argc, char* argv[])
{  
   R_RANDOM_STRUCT randomStruct;
   R_RSA_PUBLIC_KEY publicKey;
   R_RSA_PRIVATE_KEY privateKey;
   R_SIGNATURE_CTX Scontext, Vcontext;

   unsigned char seed[] = "asdfsafsafs2341131231";
   char msg1[2][1000]; //= {"hello", ",world"};
   char msg2[2][1000];

	FILE *fp;
  //unsigned char line[1000];
  if(NULL ==(fp= fopen("file1.txt", "r" )))
  { 
     printf("open file error");
     exit(0);
  }

  fgets((char *)msg1[0], 6, fp);
  fgets((char *)msg1[1], 6, fp);
 
fclose( fp ); 

 if(NULL ==(fp= fopen("file2.txt", "r" )))
  { 
     printf("open file error");
     exit(0);
  }

 fgets((char *)msg2[0], 6, fp);
  fgets((char *)msg2[1],6, fp);
 
fclose( fp ); 




   unsigned char signature[MAX_ENCRYPTED_KEY_LEN];
   unsigned int  signatureLen;
   // ���������ṹ�壬������RSA��Կ
   seed_randomStruct (seed, &randomStruct);
   create_RSAkey (&publicKey, &privateKey,1024, 1, &randomStruct);
// ��hello,world����ǩ��
 if (RE_DIGEST_ALGORITHM == R_SignInit 
                                                       (&Scontext, DA_MD5))
 { 
   printf ("digestAlgorithm is invalid\n");
   return 0;
 }
R_SignUpdate 
(&Scontext, (unsigned char *) msg1[0], strlen(msg1[0]));
R_SignUpdate
(&Scontext, (unsigned char *) msg1[1], strlen(msg1[1]));

if (RE_PRIVATE_KEY == R_SignFinal 
                                    (&Scontext, signature, &signatureLen,  &privateKey))
{
   printf ("privateKey cannot encrypt message digest\n");
   return 0;
}
shows("signature", signature, signatureLen);
// У��ǩ��
 if (RE_DIGEST_ALGORITHM ==  R_VerifyInit (&Vcontext, DA_MD5))
 { 
   printf ("digestAlgorithm is invalid\n");
   return 0;
 }
R_VerifyUpdate 
(&Vcontext,  (unsigned char *) msg2[0], strlen(msg2[0]));
   R_VerifyUpdate 
(&Vcontext,  (unsigned char *) msg2[1], strlen(msg2[1]));

   int ret = R_VerifyFinal 
(&Vcontext, signature, signatureLen, &publicKey);
printf ("verify result: ");
   switch (ret)
   {	  case 0: printf("success\n"); break;
      case RE_SIGNATURE: printf("signature is incorrect\n"); 
               break;
	  case RE_LEN: printf("signatureLen out of range\n"); break;
      case RE_PUBLIC_KEY:
         printf("publicKey cannot decrypt signature\n"); break;
   }
return 0; 
}
